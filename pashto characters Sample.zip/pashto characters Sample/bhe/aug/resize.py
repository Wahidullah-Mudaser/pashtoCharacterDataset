from PIL import Image
import glob
import cv2


img_path = 'I:\\KMUTT\\ocr pashto\\dataset\\samples\\Aphabats of Pashto Hand written-Asia\\complete\\bhe\\bhee (1).png';
im = Image.open(img_path)
print('{}'.format(img_path))
print('size: {}'.format(im.format))
print('image mode: {}'.format(im.size))


image_list = []
resized_images = []


for filename in glob.glob('I:\\KMUTT\\ocr pashto\\dataset\\samples\\Aphabats of Pashto Hand written-Asia\\complete\\bhe\\*.png'):
	img = Image.open(filename)
	image_list.append(img)

for image in image_list:
	image = image.resize((28,28))
	resized_images.append(image)
    
for (i, new)in enumerate(resized_images):
        immg = cv2.cvtColor(new, cv2.COLOR_BGR2GRAY)
     """immg.save('{}{}{}'.format('I:\\KMUTT\\ocr pashto\\dataset\\samples\\Aphabats of Pashto Hand written-Asia\\complete\\bhe\\resized\\',i+1,'.png'))
"""